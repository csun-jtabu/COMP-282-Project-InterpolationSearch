public class Filter {
    /* The goal of this method is for when wanting to see the professors only in a given department */
}
